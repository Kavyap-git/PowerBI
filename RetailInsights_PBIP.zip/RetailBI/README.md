# Retail Insights — Power BI Project (PBIP)

Built for Power BI Desktop **2.155.756.0**. Source data: `Orders.csv` (500 orders) + `Details.csv` (1,500 order lines), calendar year 2018, India retail e-commerce data.

---

## 1. Business Summary

| Item | Decision |
|---|---|
| Audience | Mixed — executives, sales, and ops/finance |
| Time comparisons | Month-over-Month only (data covers a single calendar year, so YoY isn't possible anyway) |
| Forecasting | Included — enabled via the Analytics pane's built-in forecast on the two trend line charts (Monthly Sales Trend, Monthly Profit Trend). This uses Power BI's native exponential smoothing forecast rather than a hand-coded DAX model, since it re-fits live to whatever filter context is active. |
| Targets/budgets | None exist in the source data — all KPIs are actuals only. If you have budget figures, they can be added as a new table and I can wire up variance measures. |
| Calculated columns | Measures-only, per your instruction — the one exception is `CustomerType` (Repeat vs One-Time), which must be a calculated column since it's a row-level classification, not an aggregation. |
| Branding | No logo supplied — used a neutral professional light-theme palette (steel blue / slate grey). |

## 2. Data Model — Star Schema

```
Dim_Calendar (Date) ──1:*──> Fact_OrderDetails <──*:1── Dim_Orders (Order ID)
```

- **Fact_OrderDetails** (1,500 rows, from Details.csv, grain = 1 order line): Amount, Profit, Quantity, Category, Sub-Category, Payment Mode. `OrderDate` was merged in from Orders.csv during load so the fact table relates directly to the calendar — a true star, not a snowflake. Order ID, OrderDate, Amount, Profit, and Quantity are hidden (technical/raw columns) — everything is exposed through measures instead.
- **Dim_Orders** (500 rows, from Orders.csv, grain = 1 order): Order ID, CustomerName, State, City, and a calculated `CustomerType` column (Repeat Customer vs One-Time Customer, based on order count per customer).
- **Dim_Calendar** (calculated table, 365 rows spanning the data's min/max order date): Date, Year, Month, Quarter, weekday attributes, plus sort-by-column wiring so months/quarters display in chronological order rather than alphabetical.

**Data quality notes carried over from Step 2 analysis:** zero nulls, zero duplicate rows, zero orphaned Order IDs in either direction. ~35% of order lines have negative profit — this is real signal (kept as-is and surfaced deliberately in the Profit Analysis page, not treated as an error).

## 3. Measures (36 total, organized in display folders under `_Measures`)

**Sales:** Total Sales, Total Orders, Total Quantity, Total Line Items, Average Order Value, Average Selling Price

**Profit:** Total Profit, Profit Margin %, Avg Profit per Order, Loss Making Lines, Loss Making Lines %, Profitable Lines

**Customers:** Total Customers, Avg Basket Size, Purchase Frequency, Avg Sales per Customer, Repeat Customers, Repeat Customer Rate

**Time Intelligence (MoM):** Sales Prior Month, Sales MoM Growth, Sales MoM Growth %, Profit Prior Month, Profit MoM Growth, Profit MoM Growth %, Sales MTD, Running Total Sales, Running Total Profit

**Ranking:** Category Sales Rank, SubCategory Sales Rank, Customer Sales Rank, City Sales Rank

**Dynamic Titles:** Selected Category, Executive Page Title, Sales Analysis Title

**Conditional Formatting:** Profit Margin Status Color (traffic-light hex), MoM Growth Indicator (▲/▼ text with %)

Full DAX for every measure is in `RetailInsights.SemanticModel/definition/tables/_Measures.tmdl`.

## 4. Report Pages (4 pages, 50 visuals total)

**Page 1 — Executive Overview:** 6 KPI cards (Sales, Profit, Orders, Quantity, AOV, Margin %), monthly sales & profit trend lines, sales by category (donut), sales by region (bar), top customers & top products tables, Category/State/Payment Mode slicers.

**Page 2 — Sales Analysis:** sales trend, Category→Sub-Category drill-down column chart, sales by state/city, payment mode donut, customer analysis table, monthly comparison vs prior month, quarterly comparison.

**Page 3 — Profit Analysis:** profit trend, profit by category/sub-category, profit waterfall by category, sales-vs-profit scatter by sub-category, top profit products, loss-making products (filtered to Profit < 0), MoM variance table.

**Page 4 — Customer Insights:** customer segmentation donut (Repeat vs One-Time), top customers table, purchase behaviour table (basket size, frequency), regional customer distribution.

## 5. Assumptions Made

- No target/budget values exist → all KPI visuals show actuals only.
- No product ID exists in the source data → Category/Sub-Category are kept as attributes directly on the fact table (a "degenerate dimension") rather than a separate product master table.
- "Customer Segmentation" was interpreted as Repeat vs One-Time buyer, since no other segmentation attribute (e.g. tier, industry) exists in the data.
- Loss-making product filter uses `Profit < 0` at the order-line level.

## 6. Known Limitations — Please Read

This report was hand-authored as PBIP source files (TMDL + report.json) without a live Power BI Desktop instance available to open and validate it in this environment. The semantic model (tables, relationships, all 36 measures) follows well-established TMDL syntax and is the most reliable part of this deliverable. The report layer (`report.json`) uses Power BI's classic visual container schema, which is stable but intricate — **when you first open the project, check each page for any visual that shows a formatting/query error, and let me know what you see so I can patch it.**

Deliberately **left out of the hand-authored JSON**, because they're fragile to build blind and take under a minute each directly in Desktop's UI:
- **Key Influencers** and **Smart Narrative** AI visuals (Page 4) — Insert → AI Visuals, point at Fact_OrderDetails/Dim_Orders.
- **Tooltip pages** — create a small page, set Page Information → "Allow use as tooltip," then assign it under a visual's Format → Tooltip.
- **Drill-through pages** — add a page, drag a field (e.g. SubCategory) into the Drillthrough well, right-click any bar/column to test.
- **Bookmarks and custom navigation buttons** — page tabs at the bottom of the report already provide navigation between all 4 pages; Insert → Buttons → Blank + Format → Action → Page navigation gets you branded nav buttons quickly if you want them.
- **Field parameters** — not applicable given the fixed KPI set; easy to add later (Modeling → New Parameter → Fields) if you want a "switch measure" slicer.

## 7. Deployment Instructions

1. Unzip the project, keeping `RetailInsights.pbip`, `RetailInsights.Report/`, and `RetailInsights.SemanticModel/` together in the same folder.
2. Double-click `RetailInsights.pbip` to open in Power BI Desktop 2.155.756.0 (or later).
3. Data is embedded directly in the model (no external file path to reconfigure) — go to **Home → Refresh** to load it.
4. Review each page per the Known Limitations note above and report back anything that looks off.
5. Publish to your workspace via **Home → Publish** once you're happy with it.

## 8. Future Enhancements

- Swap the embedded static data for a live connection (SQL/Excel/SharePoint) once this moves past a one-off analysis.
- Add a budget/target table to unlock variance-to-target measures and conditional KPI coloring against goals.
- Add YoY comparisons once a second year of data is available.
- Add row-level security if this needs to be shared with regional managers who should only see their own state.
